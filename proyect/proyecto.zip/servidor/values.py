# Variables globales para el servidor e interfaz
temperatura = None
humedad = None
amps = None
voltage = None
